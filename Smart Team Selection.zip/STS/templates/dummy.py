a = 'Welcome to HaranGPT, your friendly AI chatbot!'
b = a.upper()
print(b)